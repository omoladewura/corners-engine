# CORNERS ENGINE — CLOUDFLARE DEPLOYMENT

World Cup 2026 Corners/Cards Betting Analysis System
All 10 phases · Cloudflare Workers + KV

---

## FOLDER STRUCTURE

```
corners-engine/
  worker.js          ← Cloudflare Worker (API proxy + KV storage)
  wrangler.toml      ← Deployment config
  public/
    index.html       ← The full app (served as static asset)
  README.md
```

---

## PREREQUISITES

Install Node.js if you don't have it: https://nodejs.org

Then install Wrangler (Cloudflare's CLI):

```bash
npm install -g wrangler
```

Login to Cloudflare:

```bash
wrangler login
```

A browser window opens. Authorise. Done.

---

## STEP 1 — Create KV Namespace

```bash
wrangler kv:namespace create "RESULTS"
```

This outputs something like:

```
{ binding = "RESULTS", id = "abc123xyz...", preview_id = "def456uvw..." }
```

Open `wrangler.toml` and paste both values:

```toml
[[kv_namespaces]]
binding    = "RESULTS"
id         = "abc123xyz..."        ← paste here
preview_id = "def456uvw..."        ← paste here
```

---

## STEP 2 — Set Your Anthropic API Key

```bash
wrangler secret put ANTHROPIC_API_KEY
```

It will prompt:
```
Enter a secret value: ›
```

Paste your Anthropic API key. It is stored encrypted server-side.
It never appears in any file. Never touches the browser.

---

## STEP 3 — Deploy

```bash
wrangler deploy
```

Cloudflare will output your live URL:

```
https://corners-engine.YOUR-SUBDOMAIN.workers.dev
```

That's it. The app is live.

---

## LOCAL DEVELOPMENT

To run locally before deploying:

```bash
wrangler dev
```

App available at: http://localhost:8787

For local dev, create a `.dev.vars` file (never commit this):

```
ANTHROPIC_API_KEY=sk-ant-your-key-here
```

---

## WHAT THE WORKER DOES

The Worker sits between the browser and Anthropic:

```
Browser → POST /api/chat → Worker → Anthropic API
                                         ↓
Browser ←   JSON response  ← Worker ←──┘
```

Your API key lives only in the Worker environment.
It is never sent to the browser. Never in the HTML.

The Worker also handles all Results Tracker storage via Cloudflare KV:

```
GET    /api/results        → load all results
POST   /api/results        → save one result
DELETE /api/results/:id    → delete one result
DELETE /api/results        → clear all results
```

---

## UPDATING THE APP

Edit `public/index.html`, then redeploy:

```bash
wrangler deploy
```

---

## TROUBLESHOOTING

**"Authentication error" when running analysis**
→ Check your API key: `wrangler secret list`
→ Re-set if needed: `wrangler secret put ANTHROPIC_API_KEY`

**KV not saving results**
→ Verify the KV ID in wrangler.toml matches what `wrangler kv:namespace list` shows

**Wrangler login issues**
→ Try: `wrangler logout` then `wrangler login` again

---

## TOKEN LIMITS

Each engine phase uses a dedicated token budget (set in index.html):

| Phase | Engine | Tokens |
|-------|--------|--------|
| 1 | Web Search | 1500 |
| 2 | DNA + Referee | 2000 |
| 3 | Data Trust + Sample Trap | 1500 |
| 4 | Tournament Context + Evolution | 1500 |
| 5 | Lineup Shock | 2000 |
| 6 | Matchup + Chaos | 2000 |
| 7 | Market + Base Rate | 1500 |
| 8 | Contradiction | 3000 |
| 9 | Certainty Filter + No-Bet | 3000 |
| 10 | Adaptive Learning | 2500 |

Raw search data is capped at 1200 chars per source before injection
into downstream prompts, preventing input token bloat.
